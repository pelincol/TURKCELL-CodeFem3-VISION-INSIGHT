# web-app

Basit FastAPI arayüzü ile .mp4 video yüklenir, YOLO-CLS inference çalışır, sonuçlar .zip olarak indirilir veya SMTP ayarlıysa e-posta ile gönderilir.

## Yapı
- `app/main.py` — API ve e-posta gönderimi
- `app/inference.py` — inference pipeline
- `app/templates/index.html` — basit UI
- `app/requirements.txt` — bağımlılıklar
- `Dockerfile`, `.dockerignore`, `.env.example`, `.gitignore`

## Notlar
- `best.pt` container içine `-v ...:/workspace/best.pt:ro` ile mount edip `.env` içinde `BEST_PT_PATH=/workspace/best.pt` ayarla.
- GPU gerekiyorsa uygun `torch+cuda` kurulumu gerekir (bu image CPU içindir).
    