# start_local.ps1
$ErrorActionPreference = "Stop"
$IMAGE_NAME = "web-app-image"

# 1) Build
docker build -t $IMAGE_NAME .

# 2) best.pt yolunu çöz
$host_pt = (Resolve-Path .\best.pt).Path

# 3) Run
# .env kullanmıyorsan alttaki --env-file satırını sil veya yorum satırı yap.
docker run --rm -p 8080:8080 `
  --env-file .env `
  -v "${host_pt}:/workspace/best.pt:ro" `
  $IMAGE_NAME
