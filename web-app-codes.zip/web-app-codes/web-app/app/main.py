import os
import shutil
import tempfile
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import asyncio
import smtplib
from email.message import EmailMessage
import gdown

from inference import run_video_inference

app = FastAPI()
BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

BEST_PT_PATH = os.environ.get("BEST_PT_PATH", "/workspace/best.pt")
BEST_PT_GDRIVE_ID = os.environ.get("BEST_PT_GDRIVE_ID", "")
SMTP_HOST = os.environ.get("SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587") or 587)
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASS = os.environ.get("SMTP_PASS", "")

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/process")
async def process(video: UploadFile = File(...), email: str = Form(...), use_gdrive_ckpt: str = Form(None)):
    if not video.filename.lower().endswith(".mp4"):
        return JSONResponse({"error": "Sadece .mp4 uzantılı dosya kabul edilir."}, status_code=400)

    tmpdir = Path(tempfile.mkdtemp(prefix="yolo_run_"))
    try:
        video_path = tmpdir / video.filename
        with open(video_path, "wb") as f:
            shutil.copyfileobj(video.file, f)

        if use_gdrive_ckpt and BEST_PT_GDRIVE_ID:
            ckpt_path = tmpdir / "best.pt"
            url = f"https://drive.google.com/uc?id={BEST_PT_GDRIVE_ID}"
            gdown.download(url, str(ckpt_path), quiet=False)
        else:
            ckpt_path = Path(BEST_PT_PATH)
            if not ckpt_path.exists():
                alt = Path("./best.pt")
                if alt.exists(): ckpt_path = alt
                else: return JSONResponse({"error": "best.pt bulunamadı. BEST_PT_PATH veya BEST_PT_GDRIVE_ID ayarlayın."}, status_code=500)

        loop = asyncio.get_event_loop()
        zip_path = await loop.run_in_executor(None, lambda: run_video_inference(str(video_path), str(ckpt_path), str(tmpdir)))

        if SMTP_HOST and SMTP_USER and SMTP_PASS:
            try:
                send_email_with_attachment(
                    smtp_host=SMTP_HOST,
                    smtp_port=SMTP_PORT,
                    smtp_user=SMTP_USER,
                    smtp_pass=SMTP_PASS,
                    to_addr=email,
                    subject="VISION-INSIGHT - Inference Sonuçları",
                    body="Ekte inference sonuçlarınız bulunmaktadır.",
                    attachment_path=zip_path
                )
                return JSONResponse({"message": "İşlem tamamlandı. Sonuç zip e-posta ile gönderildi."})
            except Exception as e:
                # ESKİ: JSON + "download" alanı (404'a sebep oluyordu)
                # return JSONResponse({"message": f"İşlem tamamlandı ancak e-posta gönderilemedi: {e}", "download": str(zip_path)})

                # YENİ: Doğrudan dosyayı indir
                filename = Path(zip_path).name
                return FileResponse(zip_path, filename=filename, media_type="application/zip")
        else:
            # SMTP yoksa zaten doğrudan indirtiyoruz
            return FileResponse(zip_path, filename=Path(zip_path).name, media_type="application/zip")
    finally:
        # debug için geçici klasörü tutuyoruz; prod'da temizleyebilirsin
        pass

def send_email_with_attachment(smtp_host, smtp_port, smtp_user, smtp_pass, to_addr, subject, body, attachment_path):
    msg = EmailMessage()
    msg["From"] = smtp_user
    msg["To"] = to_addr
    msg["Subject"] = subject
    msg.set_content(body)
    with open(attachment_path, "rb") as f:
        data = f.read()
    msg.add_attachment(data, maintype="application", subtype="zip", filename=Path(attachment_path).name)
    with smtplib.SMTP(smtp_host, smtp_port) as s:
        s.starttls(); s.login(smtp_user, smtp_pass); s.send_message(msg)
