import os, gc, json, shutil
from datetime import datetime
from collections import Counter, defaultdict
import cv2
import numpy as np
import pandas as pd
from ultralytics import YOLO
import torch

def run_video_inference(video_path: str, ckpt_path: str, out_root: str):
    IMG_SIZE     = 224
    BATCH_INFER  = 64
    TARGET_FPS   = 15
    SMOOTH_WIN   = 5
    WRITE_ANNOTATED = True
    HALF = False

    assert os.path.exists(ckpt_path), f"best.pt bulunamadı: {ckpt_path}"
    device = 0 if torch.cuda.is_available() else "cpu"
    model = YOLO(ckpt_path)
    if HALF and device != "cpu":
        model.model.half()

    cap = cv2.VideoCapture(video_path)
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    src_w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    src_h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    src_n   = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    stride  = max(1, int(round(src_fps / TARGET_FPS)))
    eff_fps = src_fps / stride
    cap.release()

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_name = f"VIDEO_EVAL_{ts}"
    EVAL_DIR = os.path.join(out_root, base_name)
    os.makedirs(EVAL_DIR, exist_ok=True)

    CSV_FRAMES   = os.path.join(EVAL_DIR, "per_frame_predictions.csv")
    CSV_SEGMENTS = os.path.join(EVAL_DIR, "segments.csv")
    JSON_SUMMARY = os.path.join(EVAL_DIR, "summary.json")
    VID_OUT      = os.path.join(EVAL_DIR, "annotated.mp4")

    def _color_for(i):
        palette = [
            (60,180,255), (80,220,100), (240,180,70),
            (200,120,255), (60,60,255), (60,255,255),
            (120,120,120), (180,180,60), (255,120,120),
        ]
        return palette[i % len(palette)]

    names = None
    frame_idxs_src, times_sec = [], []
    top1_ids, top1_confs, top5_list = [], [], []
    batch_imgs, batch_meta = [], []

    def run_batch():
        nonlocal batch_imgs, batch_meta, names
        if not batch_imgs: return
        preds = model.predict(batch_imgs, imgsz=IMG_SIZE, device=device, verbose=False)
        if names is None: names = preds[0].names
        for pr, (src_idx, t_sec) in zip(preds, batch_meta):
            probs = pr.probs
            tid = int(probs.top1)
            conf1 = float(probs.data[tid])
            t5_ids = list(map(int, probs.top5))
            t5 = []
            for k in t5_ids:
                nm = names.get(k, str(k)) if isinstance(names, dict) else (names[k] if k < len(names) else str(k))
                t5.append((k, nm, float(probs.data[k])))

            frame_idxs_src.append(src_idx)
            times_sec.append(t_sec)
            top1_ids.append(tid)
            top1_confs.append(conf1)
            top5_list.append(t5)
        batch_imgs, batch_meta = [], []
        gc.collect()

    cap = cv2.VideoCapture(video_path)
    src_idx = -1
    while True:
        ok, img = cap.read()
        if not ok: break
        src_idx += 1
        if (src_idx % stride) != 0: continue
        t_sec = src_idx / src_fps
        batch_imgs.append(img)
        batch_meta.append((src_idx, t_sec))
        if len(batch_imgs) >= BATCH_INFER: run_batch()
    run_batch()
    cap.release()

    if not top1_ids:
        raise RuntimeError("Hiç örnek frame çıkarılamadı; TARGET_FPS veya stride’ı kontrol et.")

    def smooth_majority(ids, win):
        if win <= 1 or win % 2 == 0: return ids
        r, half, n = [], win // 2, len(ids)
        for i in range(n):
            s = max(0, i - half); e = min(n, i + half + 1)
            seg = ids[s:e]; c = Counter(seg).most_common(1)[0][0]
            r.append(int(c))
        return r

    ids_raw = list(top1_ids)
    ids_smooth = smooth_majority(ids_raw, SMOOTH_WIN)
    names_map = names if isinstance(names, dict) else {i:n for i,n in enumerate(names)}

    segments = []
    if ids_smooth:
        cur_id, start_i = ids_smooth[0], 0
        for i in range(1, len(ids_smooth)):
            if ids_smooth[i] != cur_id:
                st_src = frame_idxs_src[start_i]; en_src = frame_idxs_src[i-1]
                st_t   = times_sec[start_i];       en_t   = times_sec[i-1]
                segments.append({
                    "class_id": int(cur_id),
                    "class_name": names_map.get(int(cur_id), str(cur_id)),
                    "start_frame_src": int(st_src),
                    "end_frame_src":   int(en_src),
                    "start_sec": float(st_t),
                    "end_sec":  float(en_t),
                    "duration_sec": float(max(0.0, en_t - st_t + (1.0/eff_fps)))
                })
                cur_id, start_i = ids_smooth[i], i
        st_src = frame_idxs_src[start_i]; en_src = frame_idxs_src[len(ids_smooth)-1]
        st_t   = times_sec[start_i];      en_t   = times_sec[len(ids_smooth)-1]
        segments.append({
            "class_id": int(cur_id),
            "class_name": names_map.get(int(cur_id), str(cur_id)),
            "start_frame_src": int(st_src),
            "end_frame_src":   int(en_src),
            "start_sec": float(st_t),
            "end_sec":  float(en_t),
            "duration_sec": float(max(0.0, en_t - st_t + (1.0/eff_fps)))
        })

    dur_by_cls, count_by_cls = defaultdict(float), defaultdict(int)
    for seg in segments:
        dur_by_cls[seg["class_name"]]  += seg["duration_sec"]
        count_by_cls[seg["class_name"]] += 1

    rows = []
    for i in range(len(times_sec)):
        t5 = [{"id": k, "name": n, "conf": c} for (k,n,c) in top5_list[i]]
        rows.append({
            "frame_src": frame_idxs_src[i],
            "time_sec":  times_sec[i],
            "top1_id_raw": int(ids_raw[i]),
            "top1_name_raw": names_map.get(int(ids_raw[i]), str(ids_raw[i])),
            "top1_id_smooth": int(ids_smooth[i]),
            "top1_name_smooth": names_map.get(int(ids_smooth[i]), str(ids_smooth[i])),
            "top1_conf": float(top1_confs[i]),
            "top5": json.dumps(t5, ensure_ascii=False)
        })
    pd.DataFrame(rows).to_csv(CSV_FRAMES, index=False)
    pd.DataFrame(segments).to_csv(CSV_SEGMENTS, index=False)

    summary = {
        "video_path": video_path,
        "checkpoint": ckpt_path,
        "img_size": IMG_SIZE,
        "target_fps": TARGET_FPS,
        "effective_fps": eff_fps,
        "stride": stride,
        "smoothing_window": SMOOTH_WIN,
        "classes": names_map,
        "per_class": {
            k: {"segments": int(count_by_cls[k]), "total_sec": float(dur_by_cls[k])}
            for k in sorted(dur_by_cls.keys())
        }
    }
    with open(JSON_SUMMARY, "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    if WRITE_ANNOTATED:
        cap = cv2.VideoCapture(video_path)
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        out = cv2.VideoWriter(VID_OUT, fourcc, eff_fps, (src_w, src_h))
        for i in range(len(times_sec)):
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idxs_src[i])
            ok, frame = cap.read()
            if not ok: continue
            cid = int(ids_smooth[i])
            cname = names_map.get(cid, str(cid))
            conf = top1_confs[i]
            tsec = times_sec[i]
            label = f"{cname}  {conf:.2f}  t={tsec:6.2f}s"
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
            cv2.rectangle(frame, (10, 10), (10+tw+10, 10+th+10), _color_for(cid), -1)
            cv2.putText(frame, label, (15, 10+th+2), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2, cv2.LINE_AA)
            progress = i / max(1, (len(times_sec)-1))
            bar_w = int(progress * src_w)
            cv2.rectangle(frame, (0, src_h-12), (bar_w, src_h), _color_for(cid), -1)
            out.write(frame)
        out.release(); cap.release()

    zip_path = os.path.join(out_root, f"{base_name}.zip")
    shutil.make_archive(os.path.join(out_root, base_name), "zip",
                        root_dir=os.path.dirname(EVAL_DIR),
                        base_dir=base_name)
    return zip_path
